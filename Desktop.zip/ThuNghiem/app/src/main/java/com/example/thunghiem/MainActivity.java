package com.example.thunghiem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textPercent;
    ProgressBar progressBar;
    Button btnStart;
    int percent = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textPercent = (TextView) findViewById(R.id.text_percent);
        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        btnStart = (Button) findViewById(R.id.btn_start);

        progressBar.setMax(100);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {
                        for (percent = 0 ; percent < 100 ; percent++){
                            // hàm này để  xử lý giao diện trong luồng thread
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    textPercent.setText(percent + 1 + "%");
                                    progressBar.setProgress(percent + 1);
                                }
                            });
                            SystemClock.sleep(100);
                        }
                    }
                }.start();
            }
        });
    }
}


