package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {
    TextView tvThongBao;
    Button btLuu;
    EditText etHoTen, etMaSo;
    RadioButton rbNam, rbNu;
    Spinner spinner;
    String namSinh = "";
    String maSo = "";
    String gioiTinh = "";
    SinhVien sinhVien1, sinhVien2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        setTitle("Thêm sinh viên ");
        anhXa();
        nhanThongTin();
        spinner();
        luuThongTin();
    }

    public void anhXa() {
        tvThongBao = findViewById(R.id.tvThongBao);
        spinner = findViewById(R.id.spinner);
        etMaSo = findViewById(R.id.etMaSo);
        etHoTen = findViewById(R.id.et_ho_ten);

        btLuu = findViewById(R.id.btluu);
        rbNam = findViewById(R.id.rbNam);
        rbNu = findViewById(R.id.rbNu);
    }

    public void nhanThongTin() {
        Intent intent = getIntent();
        if (intent.getStringExtra("key_hoten") != null) {
            maSo = intent.getStringExtra("key_maso");
            etHoTen.setText(intent.getStringExtra("key_hoten"));
            etMaSo.setText(intent.getStringExtra("key_maso"));
            if (intent.getStringExtra("key_gioitinh").equals("Nam")) {
                rbNam.setChecked(true);
                gioiTinh = intent.getStringExtra("key_gioitinh");
            } else {
                rbNu.setChecked(true);
            }

            sinhVien1 = new SinhVien(intent.getStringExtra("key_hoten"),
                    intent.getStringExtra("key_maso"),
                    intent.getStringExtra("key_gioitinh"),
                    intent.getStringExtra("key_namsinh"));
        }
    }

    public void luuThongTin() {
        tvThongBao.setVisibility(View.INVISIBLE);
        btLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((etHoTen.getText().toString().equals("") == false) && ((etMaSo.getText().toString().equals("")) == false)) {
                    Intent intent = new Intent(Main2Activity.this, MainActivity.class);
                    String hoTen = chuanHoa(etHoTen.getText().toString());
                    intent.putExtra("key_hoten", hoTen);  // Truyền một String
                    intent.putExtra("key_maso", etMaSo.getText().toString());
                    intent.putExtra("key_rdonam", rbNam.isChecked());
                    intent.putExtra("key_namsinh", namSinh);
                    if (etMaSo.getText().equals(maSo) == false) {
                        intent.putExtra("key_masoxoa", maSo);
                    }

                    if (rbNam.isChecked()) {
                        gioiTinh = "Nam";
                    } else {
                        gioiTinh = "Nu";
                    }

                    sinhVien2 = new SinhVien(etHoTen.getText().toString(), etMaSo.getText().toString(), gioiTinh, namSinh);
                    if (sinhVien1 != null) {
                        if (sinhVien1.equals(sinhVien2)) {
                            intent.putExtra("check", true);
                        } else {
                            intent.putExtra("check", false);
                        }
                    }
                    startActivity(intent);
                } else {
                    tvThongBao.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    public void spinner() {
        final ArrayList<String> arrayNamSinh = new ArrayList<String>();
        arrayNamSinh.add("1997");
        arrayNamSinh.add("1998");
        arrayNamSinh.add("1999");
        arrayNamSinh.add("2000");
        arrayNamSinh.add("2001");
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayNamSinh);
        Intent intent = getIntent();
        int i = arrayAdapter.getPosition(intent.getStringExtra("key_namsinh"));
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinner.setAdapter(arrayAdapter);
        spinner.setSelection(i);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                namSinh = arrayNamSinh.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public String chuanHoa(String s1) {
        String hoTen = "";
        s1 = s1.toLowerCase();
        String[] arr = s1.split(" ");
        for (String s : arr) {
            if (s.equals("") == false) {
                hoTen = hoTen + String.valueOf(s.charAt(0)).toUpperCase() + s.substring(1) + " ";
            }
        }
        return hoTen;
    }
}
