package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ImageButton imbt;
    Database database;
    ListView listViewSinhVien;
    SearchView searchView;
    ArrayList<SinhVien> arraySinhVien;
    SinhVienAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Danh sách sinh viên");
        imbt = findViewById(R.id.imgbt);
        imbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                startActivity(intent);
            }
        });

        listViewSinhVien = findViewById(R.id.listviewsinhvien);
        arraySinhVien = new ArrayList<SinhVien>();
        adapter = new SinhVienAdapter(this,R.layout.noidungdong,arraySinhVien);
        listViewSinhVien.setAdapter(adapter);

        database = new Database(this,"sinhvien.sqlite",null,1);
        database.queryData("CREATE TABLE IF NOT EXISTS SinhVien(" +
                "Id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "HOTEN VARCHAR(50)," +
                "MASO VARCHAR(10)," +
                "GIOITINH VARCHAR(10)," +
                "NAMSINH VARCHAR(10))");

        Intent intent = getIntent();
        String hoTen = intent.getStringExtra("key_hoten");
        String maSo = intent.getStringExtra("key_maso");
        String maSoXoa = intent.getStringExtra("key_masoxoa");
        String namSinh = intent.getStringExtra("key_namsinh");
        boolean check = intent.getBooleanExtra("key_rdonam",true);
        String gioiTinh ;
        if (check){
            gioiTinh = "Nam";
        }else
            gioiTinh = "Nu";

        getDaTaSinhVien();

        // check mã đã tồn tại chưa và quyết định cho lưu vào database
        int x = 0;
        if ((hoTen != null) && (maSo != null)) {
            for (SinhVien sinhVien : arraySinhVien) {
                if (maSo.equals(sinhVien.getMaSo())) {
                    if (intent.getBooleanExtra("check", true)) {
                        Toast.makeText(this, "Mã số đã tồn tại ! ", Toast.LENGTH_SHORT).show();
                        x = 1;
                    }
                }
            }
            if (intent.getBooleanExtra("check", true) == false) {
                for (SinhVien sinhVien : arraySinhVien) {
                    if (maSo.equals(maSoXoa)) {
                        x = 0;
                        Toast.makeText(this, "Lưu thành công ! ", Toast.LENGTH_SHORT).show();
                    } else {
                        if (maSo.equals(sinhVien.getMaSo())) {
                            Toast.makeText(this, "Mã số đã tồn tại ! ", Toast.LENGTH_SHORT).show();
                            x = 1;
                        }
                    }
                }
            }
            if (x == 0) {
                database.queryData("delete from SinhVien where MASO='" + maSoXoa + "'");
                database.queryData("INSERT INTO SinhVien VALUES(null,'" + hoTen + "','" + maSo + "','" + gioiTinh + "','" + namSinh + "')");
            }
        }

//        database.queryData("DELETE FROM SinhVien");

        searchView = findViewById(R.id.searchView);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                        Cursor tenTimKiem = database.Getdata("SELECT * FROM SinhVien where HOTEN LIKE '%"+query+"%'");
                        arraySinhVien.clear();
                        while (tenTimKiem.moveToNext()){
                            String hoTen = tenTimKiem.getString(1);
                            String maSo = tenTimKiem.getString(2);
                            String gioiTinh = tenTimKiem.getString(3);
                            String namSinh = tenTimKiem.getString(4);
                            SinhVien sinhVien = new SinhVien(hoTen,maSo,gioiTinh,namSinh);
                            arraySinhVien.add(sinhVien);
                        }
                        adapter.notifyDataSetChanged();
                        if (arraySinhVien.size() == 0){
                            Toast.makeText(MainActivity.this, "không có sinh viên bạn muốn tìm", Toast.LENGTH_SHORT).show();
                        }
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    Cursor tenTimKiem = database.Getdata("SELECT * FROM SinhVien where HOTEN LIKE '%"+newText+"%'");
                    arraySinhVien.clear();
                    while (tenTimKiem.moveToNext()){
                        String hoTen = tenTimKiem.getString(1);
                        String maSo = tenTimKiem.getString(2);
                        String gioiTinh = tenTimKiem.getString(3);
                        String namSinh = tenTimKiem.getString(4);
                        SinhVien sinhVien = new SinhVien(hoTen,maSo,gioiTinh,namSinh);
                        arraySinhVien.add(sinhVien);
                    }
                    adapter.notifyDataSetChanged();

                    if (arraySinhVien.size() == 0){
                        Toast.makeText(MainActivity.this, "không có sinh viên bạn muốn tìm", Toast.LENGTH_SHORT).show();
                    }
                    if (newText.equals("")){
                        arraySinhVien.clear();
                        getDaTaSinhVien();
                    }
                    return false;
                }
            });
        }
        arraySinhVien.clear();
        getDaTaSinhVien();

        listViewSinhVien.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                dialogShow(position);
            }
        });

    }

    private void dialogShow(int i){
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog);

        TextView txtHoTen,txtMaSo,txtGioiTinh,txtNamSinh;
        txtHoTen = dialog.findViewById(R.id.daltxtHoTen);
        txtMaSo = dialog.findViewById(R.id.daltxtMaSo);
        txtGioiTinh = dialog.findViewById(R.id.daltxtGioiTinh);
        txtNamSinh = dialog.findViewById(R.id.daltxtNamSinh);

        txtHoTen.setText("Họ tên : " + arraySinhVien.get(i).getHoTen());
        txtMaSo.setText("Mã số : " + arraySinhVien.get(i).getMaSo());
        txtGioiTinh.setText("Giới tính : " + arraySinhVien.get(i).getGioiTinh());
        txtNamSinh.setText("Năm Sinh : " + arraySinhVien.get(i).getNamSinh());
        dialog.show();
    }

    public void xoanhacnho(final String tenSinhVien, final String maSo){

        AlertDialog.Builder dialogxoa = new AlertDialog.Builder(this);
        dialogxoa.setMessage("Bạn chắc chắn muốn xóa "+tenSinhVien+" ?");
        dialogxoa.setPositiveButton("Có", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                database.queryData("delete from SinhVien where MASO='"+maSo+"'");
                arraySinhVien.clear();
                getDaTaSinhVien();
                database.queryData("delete from SinhVien where MASO='"+maSo+"'");
                adapter.notifyDataSetChanged();
            }
        });
        dialogxoa.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        dialogxoa.show();

    }

    public void suaThongTin(String hoTen,String maSo,String gioiTinh,String namSinh){
        Intent intent=new Intent(MainActivity.this,Main2Activity.class);
        intent.putExtra("key_hoten",hoTen);  // Truyền một String
        intent.putExtra("key_maso",maSo);
        intent.putExtra("key_gioitinh",gioiTinh);
        intent.putExtra("key_namsinh",namSinh);
        startActivity(intent);
    }

    public void getDaTaSinhVien(){
        Cursor dataSinhVien =database.Getdata("SELECT * FROM SinhVien");
        while (dataSinhVien.moveToNext()){
            String hoTen = dataSinhVien.getString(1);
            String maSo = dataSinhVien.getString(2);
            String gioiTinh = dataSinhVien.getString(3);
            String namSinh = dataSinhVien.getString(4);
            SinhVien sinhVien = new SinhVien(hoTen,maSo,gioiTinh,namSinh);
            arraySinhVien.add(sinhVien);
        }
        adapter.notifyDataSetChanged();
    }
}
