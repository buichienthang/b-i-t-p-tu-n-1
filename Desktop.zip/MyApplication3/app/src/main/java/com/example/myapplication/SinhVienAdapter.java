package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;
import java.util.Optional;

public class SinhVienAdapter extends BaseAdapter {

    private MainActivity context;
    private  int layout;
    private List<SinhVien> sinhVienList;

    public SinhVienAdapter(Context context, int layout, List<SinhVien> sinhVienList) {
        this.context = (MainActivity) context;
        this.layout = layout;
        this.sinhVienList = sinhVienList;
    }

    @Override
    public int getCount() {
        return sinhVienList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }


    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(layout,null);
        TextView hoTen = convertView.findViewById(R.id.txtHoTen);
        TextView maSo = convertView.findViewById(R.id.txtMaSo);
        ImageView imgX = convertView.findViewById(R.id.imgx);
        ImageView imgS = convertView.findViewById(R.id.imgs);
        final SinhVien sinhVien = sinhVienList.get(position);
        hoTen.setText(sinhVien.getHoTen());
        maSo.setText(sinhVien.getMaSo());
        imgX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.xoanhacnho(sinhVien.getHoTen(),sinhVien.getMaSo());
            }
        });
        imgS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.suaThongTin(sinhVien.getHoTen(),sinhVien.getMaSo(),sinhVien.getGioiTinh(),sinhVien.getNamSinh());
            }
        });


        return convertView;
    }
}
