package com.example.myapplication;

import android.widget.TextView;

import javax.xml.transform.Templates;

import androidx.annotation.Nullable;

public class SinhVien {
    private String hoTen,maSo,gioiTinh,namSinh;

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getMaSo() {
        return maSo;
    }

    public void setMaSo(String maSo) {
        this.maSo = maSo;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(String namSinh) {
        this.namSinh = namSinh;
    }

    public SinhVien(String hoTen, String maSo, String gioiTinh, String namSinh) {
        this.hoTen = hoTen;
        this.maSo = maSo;
        this.gioiTinh = gioiTinh;
        this.namSinh = namSinh;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (obj instanceof SinhVien){
            SinhVien sinhVien2 = ((SinhVien) obj);
            if ((sinhVien2.getHoTen().equals(this.hoTen)) && (sinhVien2.getMaSo().equals(this.maSo))
                    && (sinhVien2.getNamSinh().equals(this.namSinh))
                    && (sinhVien2.getGioiTinh().equals(this.gioiTinh))){
                return true;
            }else{
                return false;
            }
        }else {
            return false;
        }
    }
}
